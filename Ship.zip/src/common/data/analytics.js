const topPages = [
    {
        id: 1,
        page: "/themesbrand/skote-25867",
        active: "99",
        user: "25.3%"
    },
    {
        id: 2,
        page: "/dashonic/chat-24518",
        active: "86",
        user: "22.7%"
    },
    {
        id: 3,
        page: "/skote/timeline-27391",
        active: "64",
        user: "18.7%"
    },
    {
        id: 4,
        page: "/themesbrand/minia-26441",
        active: "53",
        user: "14.2%"
    },
    {
        id: 5,
        page: "/dashon/dashboard-29873",
        active: "33",
        user: "12.6%"
    },
    {
        id: 6,
        page: "/doot/chats-29964",
        active: "20",
        user: "10.9%"
    },
    {
        id: 7,
        page: "/minton/pages-29739",
        active: "10",
        user: "07.3%"
    },
];


export {topPages}